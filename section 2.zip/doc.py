

class Student:
    def __init__(self, student_id, name, marks):
        self.student_id = student_id
        self.name = name
        self.marks = self.validate_marks(marks)
        self.average = self.calculate_average()
        self.status = self.get_status()
        self.factorial_subjects = math.factorial(len(self.marks))

    def validate_marks(self, marks):
        valid_marks = []
        for m in marks:
            if isinstance(m, (int, float)) and 0 <= m <= 100:
                valid_marks.append(m)
            else:
                print(f"Invalid mark '{m}' detected. Skipped.")
        return valid_marks

    def calculate_average(self):
        if len(self.marks) == 0:
            return 0
        return sum(self.marks) / len(self.marks)

    def get_status(self):
        return "PASS" if self.average >= 40 else "FAIL"

    def report(self):
        print("\n--- Student Report ---")
        print("Student Record Saved Successfully")
        print(f"Student ID: {self.student_id}")
        print(f"Name: {self.name}")
        print(f"Average Marks: {self.average:.1f}")
        print(f"Result Status: {self.status}")
        print(f"Factorial of Subjects: {self.factorial_subjects}")
        print("----------------------\n")

students = {}
passed_students = []

def add_student(student_id, name, marks):
    student = Student(student_id, name, marks)
    students[student_id] = student
    if student.status == "PASS":
        passed_students.append(student)
    student.report()

def compare_students(id1, id2):
    if id1 in students and id2 in students:
        s1, s2 = students[id1], students[id2]
        if s1.average > s2.average:
            print(f"{s1.name} has a higher average ({s1.average:.2f}) than {s2.name} ({s2.average:.2f})")
        elif s1.average < s2.average:
            print(f"{s2.name} has a higher average ({s2.average:.2f}) than {s1.name} ({s1.average:.2f})")
        else:
            print(f"Both {s1.name} and {s2.name} have the same average ({s1.average:.2f})")
    else:
        print("One or both student IDs not found.")

def interactive_input():
    student_id = input("Enter Student ID: ")
    name = input("Enter Student Name: ")
    marks = []
    num_subjects = int(input("Enter number of subjects: "))
    for i in range(num_subjects):
        try:
            mark = float(input(f"Enter mark for subject {i+1}: "))
            if 0 <= mark <= 100:
                marks.append(mark)
            else:
                print("Invalid mark! Must be between 0 and 100. Skipped.")
        except ValueError:
            print("Invalid input! Skipped.")
    add_student(student_id, name, marks)

if __name__ == "__main__":
    interactive_input()
    interactive_input()
    compare_students("101", "102")
    print("Passed Students:", [s.name for s in passed_students])