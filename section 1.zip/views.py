from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from .models import Student
from .forms import StudentForm
import csv, io

def add_student(request):
    if request.method == 'POST':
        form = StudentForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return JsonResponse({'success': True})
        return JsonResponse({'errors': form.errors}, status=400)
    return render(request, 'students/add_student.html', {'form': StudentForm()})

def student_list(request):
    students = Student.objects.all()
    return render(request, 'students/student_list.html', {'students': students})

def student_detail(request, id):
    student = get_object_or_404(Student, id=id)
    return render(request, 'students/student_detail.html', {'student': student})

def upload_csv(request):
    if request.method == 'POST':
        csv_file = request.FILES['file']
        data = io.TextIOWrapper(csv_file.file, encoding='utf-8')
        reader = csv.DictReader(data)

        for row in reader:
            Student.objects.create(
                name=row['name'],
                email=row['email'],
                age=row['age'],
                profile_image='profiles/default.png'
            )
        return redirect('student_list')